import { Component, Input } from '@angular/core';
import { StationObject } from './domain/models/stationobject';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // @Input() selectedStation: StationObject;

   selectedStation:  StationObject;

  title = 'Gas-Station-Project';



}
