import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { StationObject } from '../domain/models/stationobject';
import { User } from '../domain/models/account';
import { STATIONS } from '../stations';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})

export class MainComponent implements OnInit {

  currUser: User;
  newUser: User;
  users: User[];
  selectedStation: StationObject = {};
  radius: number;
  searchInput: string;
  activeStations: StationObject[];

  email: string;
  password: string;

  constructor(private cdRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.radius = 10;
    this.currUser = {};
    this.newUser = {};
    this.email = "";
    this.password = "";
    this.users = [
      {
        firstName: "Daniel",
        lastName: "Willborn",
        email: "dwillborn@smu.edu",
        password: "password1"
      },
      {
        firstName: "Sterling",
        lastName: "Conner",
        email: "sconner@smu.edu",
        password: "abc123"
      },
      {
        firstName: "Eli",
        lastName: "Laird",
        email: "elaird@smu.edu",
        password: "qwerty456"
      }
    ];
    this.activeStations = STATIONS;
    this.cdRef.detectChanges();
  }

  setActiveStations(stations: StationObject[]) {
    this.activeStations = stations;
  }

  login() {
    for (let i = 0; i < this.users.length; i++) {
      if (this.email === this.users[i].email && this.password === this.users[i].password) {
        this.currUser = this.users[i];
        break;
      }
    }
    this.password = "";
    this.email = "";
  }

  create() {
    if (this.newUser.firstName && this.newUser.lastName && this.newUser.email && this.newUser.password) {
      this.users.push(this.newUser);
      this.currUser = this.newUser;
    }
    this.newUser = {};
  }

  logout() {
    this.currUser = {};
  }
}
