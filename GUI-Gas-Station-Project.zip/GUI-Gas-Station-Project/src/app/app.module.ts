import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { StationInfoComponent } from './station-info/station-info.component';
import { FilterComponent } from './filter/filter.component';
import { MapComponent } from './map/map.component';
import { StationComponent } from './station/station.component';
import { ImageMapComponent } from './image-map/image-map.component';
import { MainComponent } from './main/main.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SidebarComponent,
    StationInfoComponent,
    FilterComponent,
    MapComponent,
    StationComponent,
    ImageMapComponent,
    MainComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
