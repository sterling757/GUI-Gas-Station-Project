import { User } from './domain/models/account';

export const USERS: User[] = [
  {
    firstName: "Daniel",
    lastName: "Willborn",
    email: "dwillborn@smu.edu",
    password: "password1"
  },
  {
    firstName: "Sterling",
    lastName: "Conner",
    email: "sconner@smu.edu",
    password: "abc123"
  },
  {
    firstName: "Eli",
    lastName: "Laird",
    email: "elaird@smu.edu",
    password: "qwerty456"
  }
]

