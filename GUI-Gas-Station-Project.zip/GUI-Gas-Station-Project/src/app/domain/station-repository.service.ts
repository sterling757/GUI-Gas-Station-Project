import { Injectable } from '@angular/core';
// import { Observable } from "rxjs/Observable";
// import { HttpClient, HttpHeaders } from "@angular/common/http";
import { catchError } from 'rxjs/operators';
import { StationObject } from './models/stationobject';

@Injectable({
  providedIn: 'root'
})
export class StationRepositoryService {

  constructor() { }
}
