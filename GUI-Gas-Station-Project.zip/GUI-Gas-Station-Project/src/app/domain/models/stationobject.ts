import { Review } from './review';

export class StationObject {
  name?: string; // name of the gas station
  address?: string; // address of the gas station
  price?: number; // avg price of the gas at the station
  distance?: number; // distance of the station from the current location
  Xpos?: number; // X position for (potential) use on the interactive map
  Ypos?: number; // Y position for (potential) use on the interactive map
  reviews?: Review[]; // list of reviews for the station
}
