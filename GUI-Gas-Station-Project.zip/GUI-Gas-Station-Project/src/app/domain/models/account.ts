import { Review } from './review';

export class User {
  firstName?: string; // first name of the user
  lastName?: string; // last name of the user
  email?: string; // email of the user, primary identifier
  password?: string; // password for the account
  reviews?: Review[]; // list of reviews this user has posted
}
