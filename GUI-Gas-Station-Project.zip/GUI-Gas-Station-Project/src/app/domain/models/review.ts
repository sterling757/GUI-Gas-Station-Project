export class Review {
  rating?: number; // rating given by the user
  text?: string; // comment the user gives in their review
}
