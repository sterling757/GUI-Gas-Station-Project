import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { catchError } from 'rxjs/operators';
import { StationObject } from "./models/stationobject";
import { Observable } from "rxjs";
import { User } from "./models/account";
import { Review } from "./models/review";

@Injectable()
export class DBManager {

  protected endPoint = "http://localhost:3000";

  protected httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    protected httpClient: HttpClient
  ) {}

  getStations(radius: number): Observable<StationObject[]> {
    return this.httpClient
    .get<StationObject[]>(`${this.endPoint}/stations/?distance<=${radius}`, this.httpOptions)
    .pipe(catchError(this.handleException));
  }

  getUser(email: string, password: string): Observable<User> {
    return this.httpClient
    .get<User>(`${this.endPoint}/users/?email=${email}/?password=${password}`, this.httpOptions)
    .pipe(catchError(this.handleException));
  }

  getReviews(address: string): Observable<Review[]> {
    return this.httpClient
    .get<Review[]>(`${this.endPoint}/reviews/?address=${address}`, this.httpOptions)
    .pipe(catchError(this.handleException));
  }

  createUser(user: User): Observable<User> {
    return this.httpClient
    .post<User>(`${this.endPoint}/users`, user, this.httpOptions)
    .pipe(catchError(this.handleException));
  }

  findStation(name: string): Observable<StationObject> {
    return this.httpClient
    .get<StationObject>(`${this.endPoint}/stations/?name=${name}`, this.httpOptions)
    .pipe(catchError(this.handleException));
  }

  postReview(review: Review): Observable<Review> {
    return this.httpClient
    .post<Review>(`${this.endPoint}/reviews`, review, this.httpOptions)
    .pipe(catchError(this.handleException));
  }

  protected handleException(exception: any) {
    var message = `${exception.status} : ${exception.statusText}\r\n${exception.message}`;
    alert(message);
    return Observable.throw(exception);
  }
}
