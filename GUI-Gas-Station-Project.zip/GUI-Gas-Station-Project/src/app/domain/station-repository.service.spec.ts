import { TestBed } from '@angular/core/testing';

import { StationRepositoryService } from './station-repository.service';

describe('StationRepositoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StationRepositoryService = TestBed.get(StationRepositoryService);
    expect(service).toBeTruthy();
  });
});
