import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs/internal/Observable';
import { Review } from './models/review';

@Injectable({
  providedIn: 'root'
})
export class ReviewRepositoryService {
  protected endpoint = 'http://18.223.212.8:4444/api/directory/review';

  protected httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Basic'
    })
  };

  constructor(
    protected httpClient: HttpClient
  ) { }

  getById(id: number): Observable<Review> {
    return this.httpClient
      .get<Review>(`${this.endpoint}/${id}`, this.httpOptions)
      .pipe(catchError(this.handleException));
  }

  add(review: Review): Observable<Review> {
    return this.httpClient
      .post<Review>(this.endpoint, review, this.httpOptions)
      .pipe(catchError(this.handleException));
  }

  protected handleException(exception: any) {
    var message = `${exception.status} : ${exception.statusText}\r\n${exception.message}`;
    alert(message);
    return Observable.throw(exception);
  }
}
