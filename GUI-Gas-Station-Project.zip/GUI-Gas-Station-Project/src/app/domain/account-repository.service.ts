import { Injectable } from '@angular/core';
// import { Observable } from "rxjs/Observable";
// import { HttpClient, HttpHeaders } from "@angular/common/http";
import { catchError } from 'rxjs/operators';
// import { Account } from "./models/account";

@Injectable({
  providedIn: 'root'
})
export class AccountRepositoryService {

  protected endPoint = "http://18.223.212.8:4444/api/";

  constructor() { }
}
