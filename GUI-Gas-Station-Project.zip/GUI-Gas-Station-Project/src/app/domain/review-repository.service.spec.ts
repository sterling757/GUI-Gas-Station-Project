import { TestBed } from '@angular/core/testing';

import { ReviewRepositoryService } from './review-repository.service';

describe('ReviewRepositoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReviewRepositoryService = TestBed.get(ReviewRepositoryService);
    expect(service).toBeTruthy();
  });
});
