import { Component, OnInit, Input } from '@angular/core';
import { StationObject } from '../domain/models/stationobject';
import { User } from '../domain/models/account';
import { Review } from '../domain/models/review';

@Component({
  selector: 'app-station-info',
  templateUrl: './station-info.component.html',
  styleUrls: ['./station-info.component.css']
})
export class StationInfoComponent implements OnInit {

  @Input() station: StationObject;
  @Input() currUser: User;

  newReview: Review;

  constructor() { }

  ngOnInit() {
    this.newReview = {};
  }

  leaveReview() {
    if (this.newReview.text && this.newReview.rating) {
      this.station.reviews.push(this.newReview);
    }
    this.newReview = {};
  }

}
