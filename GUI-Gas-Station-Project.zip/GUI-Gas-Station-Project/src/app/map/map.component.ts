import { Component, SimpleChanges, AfterViewInit, ViewChild, ElementRef, Input, ChangeDetectorRef, OnChanges } from '@angular/core';
import { FilterComponent } from '../filter/filter.component';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css'],

})

export class MapComponent implements AfterViewInit, OnChanges {


  @ViewChild("mapCanvas") mapCanvas: ElementRef;

  @ViewChild("mapImage") image: ElementRef;

  @ViewChild("pinImage") pin: ElementRef;



  protected w: number;
  protected pinw: number;
  protected h: number;
  protected pinh: number;
  protected src: string;
  protected pinsrc: string;

  private canvasElement: HTMLImageElement;
  private pinElement: HTMLImageElement;
  private ctx: CanvasRenderingContext2D;

  viewInitialized = false;

  @Input()
  radius: number;

  ngOnChanges(changes: SimpleChanges): void {
    // Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    // Add '${implements OnChanges}' to the class.

    if (!this.viewInitialized) {
      return;
    }

    this.draw();
    this.drawPins(changes.radius.currentValue);


  }



  constructor() {

    this.w = 790,
    this.h = 500;
    this.pinw = 20;
    this.pinh = 25;
    this.src = '../../assets/Photos/StaticMap.png';
    this.pinsrc = '../../assets/Photos/Gas Station PIn Icon.png'

  }


  ngAfterViewInit(): void {
    // Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    // Add 'implements AfterViewInit' to the class.
    this.viewInitialized = true;
    this.ctx = this.mapCanvas.nativeElement.getContext('2d');
    this.canvasElement = this.image.nativeElement;
    this.pinElement = this.pin.nativeElement;


  }

  draw() {

    this.ctx.clearRect(0, 0, this.w, this.h);
    this.ctx.drawImage(this.canvasElement, 0, 0, this.w, this.h);
    this.youAreHere();
    this.drawPins(this.radius);

  }

  youAreHere() {

    this.ctx.beginPath();
    this.ctx.arc(420, 240, 4, 0, 2 * Math.PI);
    this.ctx.fillStyle = 'blue';
    this.ctx.fill();
    this.ctx.lineWidth = 1;
    this.ctx.stroke();

  }

  drawPins(radius: number) {
    console.log(radius);
    if (radius === 5) {
      // 7/11
      this.ctx.drawImage(this.pinElement, 400, 250, this.pinw, this.pinh);
      // shell
      this.ctx.drawImage(this.pinElement, 360, 200, this.pinw, this.pinh);
      // daniels stop
      this.ctx.drawImage(this.pinElement, 440, 180, this.pinw, this.pinh);
    } else if (radius === 10) {
        // 7/11
        this.ctx.drawImage(this.pinElement, 400, 250, this.pinw, this.pinh);
        // shell
        this.ctx.drawImage(this.pinElement, 360, 200, this.pinw, this.pinh);
        // daniels stop
        this.ctx.drawImage(this.pinElement, 440, 180, this.pinw, this.pinh);
        // exxon
        this.ctx.drawImage(this.pinElement, 360, 100, this.pinw, this.pinh);
        // Gas
        this.ctx.drawImage(this.pinElement, 440, 300, this.pinw, this.pinh);
        // Gas Gas Gas
        this.ctx.drawImage(this.pinElement, 340, 260, this.pinw, this.pinh);
    } else if (radius === 20) {
        // 7/11
        this.ctx.drawImage(this.pinElement, 400, 250, this.pinw, this.pinh);
        // shell
        this.ctx.drawImage(this.pinElement, 360, 200, this.pinw, this.pinh);
        // daniels stop
        this.ctx.drawImage(this.pinElement, 440, 180, this.pinw, this.pinh);
        // exxon
        this.ctx.drawImage(this.pinElement, 360, 100, this.pinw, this.pinh);
        // Gas
        this.ctx.drawImage(this.pinElement, 440, 300, this.pinw, this.pinh);
        // Gas Gas Gas
        this.ctx.drawImage(this.pinElement, 340, 260, this.pinw, this.pinh);
        // Buccees
        this.ctx.drawImage(this.pinElement, 330, 400, this.pinw, this.pinh);
        // Got gas
        this.ctx.drawImage(this.pinElement, 550, 250, this.pinw, this.pinh);
    } else {
      console.log("Invalid Radius Input")
    }

  }

}
