import { Component, OnInit, Input } from '@angular/core';
import { User } from '../domain/models/account';
import { MainComponent } from '../main/main.component';
import { STATIONS } from '../stations';
import { StationObject } from '../domain/models/stationobject';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  @Input()
  currUser: User;

  stations = STATIONS;
  searchInput: string;
  activeStations: StationObject[];
  constructor(
    private main: MainComponent
  ) { }

  ngOnInit() {
  }

  onClick() : void{


    let number = this.stations.length;
    for(let i = 0;i < number;i++){
      if(this.stations[i].name == this.searchInput){
        this.main.selectedStation = this.stations[i];
        break;
      }
    }
  }


}
