import { StationObject } from './domain/models/stationobject';

export const STATIONS: StationObject[] = [
  { name: "Shell", address: "123 Avenue", price: 2.34, distance: 3, reviews: [
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
  ] },
  { name: "Exxon", address: "321 Street", price: 2.50, distance: 10, reviews: [
    {rating: 5, text:'Great service!'},
    {rating: 4, text:'Very clean!'},
    {rating: 1, text:'Awful prices'},
    {rating: 2, text:'Bathrooms are okay'},
    {rating: 2, text:'Need more snacks'}
  ] },
  { name: "7/11", address: "564 Blvd", price: 3.14, distance: 1, reviews: [
    {rating: 4, text:'Very close'},
    {rating: 2, text:'Okay service'},
    {rating: 1, text:'Very expensive'},
    {rating: 3, text:'Bathrooms are big'}
  ] },
  { name: "Bucees", address: "542 Road", price: 2.87, distance: 16, reviews: [
    {rating: 5, text:'Best bathrooms'},
    {rating: 5, text:'Amazing Service'},
    {rating: 3, text:'Decent prices!'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 4, text:'Great store!'},
  ] },
  { name: "Daniel's Stop", address: "123 Avenue", price: 2.34, distance: 3, reviews: [
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'}
  ] },
  { name: "Got Gas?", address: "321 Street", price: 2.50, distance: 11, reviews: [
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'}
  ] },
  { name: "Gas", address: "564 Blvd", price: 3.14, distance: 8, reviews: [
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'}
  ] },
  { name: "gAs GaS gaS", address: "542 Road", price: 2.87, distance: 6, reviews: [
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'},
    {rating: 1, text:'Awful prices'},
    {rating: 3, text:'The bathrooms are so great!'},
    {rating: 2, text:'Service was terrible'}
  ] }

]
