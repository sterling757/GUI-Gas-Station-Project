import { MainComponent } from './../main/main.component';
import { AppComponent } from './../app.component';
import { StationObject } from './../domain/models/stationobject';
import { Component, OnInit, EventEmitter, Output, Input} from '@angular/core';
import { STATIONS } from '../stations';

@Component({
  selector: 'app-station',
  templateUrl: './station.component.html',
  styleUrls: ['./station.component.css']
})
export class StationComponent implements OnInit {


  stations = STATIONS;

  @Input() selectedStation: StationObject;
  @Input() radius: number;
  @Input() activeStations: StationObject[];


  constructor(
    private main: MainComponent
  ) { }

  ngOnInit() {
    this.main.selectedStation = STATIONS[0];
    this.radius = this.main.radius;
  }

  onSelect(station: StationObject): void {

    this.main.selectedStation = station;

  }

}
