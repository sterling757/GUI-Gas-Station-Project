import { Component, OnInit, Input, EventEmitter, Output, ViewChild } from '@angular/core';
import { MainComponent } from '../main/main.component';
import { StationComponent } from '../station/station.component';
import { STATIONS } from '../stations';
import { StationObject } from '../domain/models/stationobject';
import { MapComponent } from '../map/map.component';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {

  private _radius;

  stations = STATIONS;
  filters: string[];

  @Input() map: MapComponent;

  @Input()
  get radius(): number {
    return this._radius;
  }

  set radius(value: number) {
    this._radius = value;
    this.radiusChange.emit(value);
  }

  activeStations: StationObject[];

  @Output()
  radiusChange: EventEmitter<number> = new EventEmitter<number>();



  constructor(
    private main: MainComponent
  ) {
    this.filters = [
      '5 Miles',
      '10 Miles',
      '20 Miles'
    ];
  }

  ngOnInit() {

  }

  initialize(radius: number) {

    this.main.radius = radius;
    this.radius = radius;

    const tempStations: StationObject[] = [];
    for (let i = 0; i < this.stations.length; i++) {
      if (this.stations[i].distance <= this.radius) {
        tempStations.push(this.stations[i]);
      }
    }
    this.main.activeStations = tempStations;
  }
  onClick(num: number) {

    this.main.radius = num;
    this.radius = num;

    const tempStations: StationObject[] = [];
    for (let i = 0; i < this.stations.length; i++) {
      if (this.stations[i].distance <= this.radius) {
        tempStations.push(this.stations[i]);
      }
    }

    this.main.activeStations = tempStations;

  }

}
